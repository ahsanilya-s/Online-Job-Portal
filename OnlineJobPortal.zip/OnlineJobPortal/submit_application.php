<?php
$servername = "localhost";
$username = "root"; // default username for XAMPP
$password = ""; // default password for XAMPP
$dbname = "job_portal";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO applications (name, email, resume) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $resume);

// Set parameters and execute
$name = $_POST['name'];
$email = $_POST['email'];
$resume = $_POST['resume'];
$stmt->execute();

echo "Application submitted successfully";

$stmt->close();
$conn->close();
?>
